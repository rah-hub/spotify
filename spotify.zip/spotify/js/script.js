console.log('Let\'s write JavaScript');
let currentSong = new Audio();
let songs;
let currFolder;

function secondsToMinutesSeconds(seconds) {
    if (isNaN(seconds) || seconds < 0) {
        return "Invalid input";
    }
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);

    const formattedMinutes = String(minutes).padStart(2, '0');
    const formattedSeconds = String(remainingSeconds).padStart(2, '0');

    return `${formattedMinutes}:${formattedSeconds}`;
}

async function getSongs(folder) {
    currFolder = folder;

    try {
        const response = await fetch(`/${folder}/`);
        const html = await response.text();

        const div = document.createElement("div");
        div.innerHTML = html;
        const links = div.querySelectorAll("a");
        songs = Array.from(links)
            .filter(link => link.href.endsWith(".mp3"))
            .map(link => decodeURI(link.href.split(`/${folder}/`)[1]));

        const songUL = document.querySelector(".songList ul");
        songUL.innerHTML = songs.map(song => `
            <li>
                <img class="invert" src="buttons/music.svg" alt="">
                <div class="info">
                    <div>${song.replaceAll("%20", " ")}</div> 
                    <div></div>
                </div>
                <div class="playnow">
                    <span>Play now</span>
                    <img class="invert" src="buttons/playbtn.svg" alt="">
                </div>
            </li>
        `).join('');

        document.querySelectorAll(".songList li").forEach(li => {
            li.addEventListener('click', () => {
                playMusic(li.querySelector('.info div').textContent.trim());
            });
        });
    } catch (error) {
        console.error('Error fetching songs:', error);
    }
}

const playMusic = (track, pause = false) => {
    currentSong.src = `/${currFolder}/` + track;
    if (!pause) {
        currentSong.play();
        play.src = "buttons/pause.svg";
    }

    document.querySelector(".songinfo").innerHTML = decodeURI(track);
    document.querySelector(".songtime").innerHTML = "00:00 / 00:00";
};




async function displayAlbums() {
    try {
        const response = await fetch('/songs/');
        const html = await response.text();

        const div = document.createElement("div");
        div.innerHTML = html;
        const anchors = div.querySelectorAll("a");
        const cardContainer = document.querySelector(".cardContainer");

        Array.from(anchors).forEach(async (anchor) => {
            const href = new URL(anchor.href);
            if (href.pathname.includes("/songs/")) {
                const folder = href.pathname.split("/").pop();
                const infoResponse = await fetch(`/${folder}/info.json`);
                const infoData = await infoResponse.json();

                const card = document.createElement("div");
                card.classList.add("card");
                card.dataset.folder = folder;
                card.innerHTML = `
                    <div class="play">
                        <img src="buttons/play.svg" alt="">
                    </div>
                    <img src="/songs/${folder}/cover.jpg" alt="">
                    <h2>${infoData.title}</h2>
                    <p>${infoData.description}</p>
                `;

                cardContainer.appendChild(card);
                card.addEventListener("click", async () => {
                    await getSongs(`songs/${folder}`);
                    playMusic(songs[0])
                });
            }
        });
    } catch (error) {
        console.error('Error fetching albums:', error);
    }
}

async function main() {
    await getSongs("songs/Animal");
    playMusic(songs[0], true);
    displayAlbums();

    play.addEventListener("click", () => {
        if (currentSong.paused) {
            currentSong.play();
            play.src = "buttons/pause.svg";
        } else {
            currentSong.pause();
            play.src = "buttons/play.svg";
        }
    });

    currentSong.addEventListener("timeupdate", () => {
        document.querySelector(".songtime").innerHTML = `${secondsToMinutesSeconds(currentSong.currentTime)} / ${secondsToMinutesSeconds(currentSong.duration)}`;
        document.querySelector(".circle").style.left = (currentSong.currentTime / currentSong.duration) * 100 + "%";
    });

    document.querySelector(".seekbar").addEventListener("click", (e) => {
        const percent = (e.offsetX / e.target.getBoundingClientRect().width) * 100;
        document.querySelector(".circle").style.left = percent + "%";
        currentSong.currentTime = (currentSong.duration * percent) / 100;
    });

    document.querySelector(".hamburger").addEventListener("click", () => {
        document.querySelector(".left").style.left = "0";
    });

    document.querySelector(".close").addEventListener("click", () => {
        document.querySelector(".left").style.left = "-120%";
    });

    previous.addEventListener("click", () => {
        const index = songs.indexOf(currentSong.src.split("/").slice(-1)[0]);
        if (index - 1 >= 0) {
            playMusic(songs[index - 1]);
        }
    });

    next.addEventListener("click", () => {
        const index = songs.indexOf(currentSong.src.split("/").slice(-1)[0]);
        if (index + 1 < songs.length) {
            playMusic(songs[index + 1]);
        }
    });

    document.querySelector(".range input").addEventListener("change", (e) => {
        currentSong.volume = e.target.value / 100;
    });

    document.querySelector(".volume img").addEventListener("click", (e) => {
        const volumeIcon = document.querySelector(".volume img");
        if (volumeIcon.src.includes("buttons/volume.svg")) {
            volumeIcon.src = volumeIcon.src.replace("buttons/volume.svg", "buttons/mute.svg");
            currentSong.volume = 0;
            document.querySelector(".range input").value = 0;
        } else {
            volumeIcon.src = volumeIcon.src.replace("buttons/mute.svg", "buttons/volume.svg");
            currentSong.volume = 0.1;
            document.querySelector(".range input").value = 10;
        }
    });
}

main();
